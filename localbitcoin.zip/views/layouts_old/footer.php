<footer>
    <a id="logo-footer" href="/"> <img src="/template/localbitcoins/img/logo.png" alt=""></a>
    <ul>
        <li class="title-foot"><p>Продукты</p></li>
        <li><a href="#">GDAX</a></li>
        <li><a href="#">Купить / Продать Bitcoin</a></li>
        <li><a href="#">Платформа разработчика</a></li>
        <li><a href="#">Торговые инструменты</a></li>
    </ul>
    <ul>
        <li class="title-foot"><p>Социум</p></li>
        <li><a href="#">Блог</a></li>
        <li><a href="#">Сообщество</a></li>
        <li><a href="#">Твиттер</a></li>
        <li><a href="#">Facebook</a></li>
    </ul>
    <ul>
        <li class="title-foot"><p>Информация</p></li>
        <li><a href="#">Купить Bitcoin</a></li>
        <li><a href="#">Купить эфир</a></li>
        <li><a href="#">Поддерживаемые страны</a></li>
    </ul>
    <ul>
        <li class="title-foot"><p>Компания</p></li>
        <li><a href="#">О нас</a></li>
        <li><a href="#">Карьера</a></li>
        <li><a href="#">Пресса</a></li>
    </ul>
</footer>
</body>
</html>