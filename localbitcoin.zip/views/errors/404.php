<?php include ROOT . '/views/layouts/guest/header.php'; ?>

<div class="error-messege"> 
    <?= $text ?>
</div> 

<?php include ROOT . '/views/layouts/footer.php'; ?>
